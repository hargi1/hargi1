import userRoutes from './users';
import recipesRoutes from './recipes';
import frontendRouter from './frontend';

export default {
  userRoutes,
  recipesRoutes,
  frontendRouter
};

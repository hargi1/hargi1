/* eslint-disable */
$("#jumbotron").vegas({
    timer: false,
    shuffle: true,
    transition: 'fade',
    animation: 'kenburns',
    slides: [
        { src: './../img/banner-1.jpg' },
        { src: './../img/banner-2.jpg' },
        { src: './../img/banner-3.jpg' }
    ]
});

import React from 'react';

export default class Footer extends React.Component {
  render() {
    return (
      <footer className="footer mt-5">
        <p>More-recipes app by bahdcoder @andela</p>
      </footer>
    );
  }
}

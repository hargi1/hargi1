let local = require('./project')

// 1
console.log(local.prime(12));

// 2
console.log(local.sum())

// 3
console.log(local.vowels("KRISHNA PADALIYA"));
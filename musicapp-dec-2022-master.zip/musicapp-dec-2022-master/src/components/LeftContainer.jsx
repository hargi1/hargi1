import React from "react";

const LeftContainer = () => {
  return <div className="col-span-2"></div>;
};

export default LeftContainer;

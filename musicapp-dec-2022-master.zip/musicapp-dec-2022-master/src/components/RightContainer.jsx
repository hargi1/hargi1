import React from "react";
import UserProfileContainer from "./UserProfileContainer";

const RightContainer = () => {
  return (
    <div className="col-span-2">
      <UserProfileContainer />
    </div>
  );
};

export default RightContainer;

exports.getIndex = (req,res) =>{
    res.render('home')
}

exports.getAbout = (req,res) =>{
    res.render('about')
}


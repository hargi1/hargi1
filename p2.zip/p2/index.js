let local = require('./coremodule')

// 1
console.log(local.factorial(5))

// 2
// console.log(local.currentDate())

// 3
console.log(local.greeting())

// 4
console.log(local.sum())

// 5
console.log(local.rectangle(10,10))

// 6
console.log(local.total())

// 7
console.log(local.vote())
